 % Run Tests Files

addpath(genpath(pwd))

% Based functions
testFunctions

% Msx Functions
testMSXFunctions

% Bin Functions
testBinFunctions

% Run epanet without DLL
testBinWithoutDLL
